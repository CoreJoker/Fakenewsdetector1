import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

True_news = pd.read_csv('True.csv')
Fake_news = pd.read_csv('Fake.csv')

True_news

Fake_news

True_news['label'] = 0
True_news

Fake_news['label'] = 1
Fake_news

dataset1 = True_news[['text','label']]
dataset2 = Fake_news[['text','label']]
dataset1, dataset2

dataset = pd.concat([dataset1 , dataset2])
dataset

dataset.shape

#checking null values
dataset.isnull().sum()

#Balanced or Unbalanced Data
dataset['label'].value_counts()

dataset1.shape,dataset2.shape #dataset1->true news, dataset2-> fake news

dataset = dataset.sample(frac = 1)
dataset.head(20)

import nltk

import re
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

ps = WordNetLemmatizer()
stopwords = stopwords.words('english')
stopwords

nltk.download('wordnet')

def cleaning_data(row):
    
    # convert text to into lower case
    row = row.lower() 
    
    # this line of code only take words from text and remove number and special character using RegX
    row = re.sub('[^a-zA-Z]' , ' ' , row)
    
    # split the data and make token.
    token = row.split() 
    
    # lemmatize the word and remove stop words like a, an , the , is ,are ...
    news = [ps.lemmatize(word) for word in token if not word in stopwords]  
    
    # finaly join all the token with space
    cleanned_news = ' '.join(news) 
    
    # return cleanned data
    return cleanned_news

dataset['text'] = dataset['text'].apply(lambda x : cleaning_data(x))

dataset.isnull().sum()

from sklearn.feature_extraction.text import TfidfVectorizer
vectorizer = TfidfVectorizer(max_features = 30000 , lowercase=False , ngram_range=(1,2))

dataset.shape

X = dataset.iloc[:35000,0]
y = dataset.iloc[:35000,1]
X.head(), y.head()

from sklearn.model_selection import train_test_split
train_data , test_data , train_label , test_label = train_test_split(X , y , test_size = 0.2 ,random_state = 0)

vec_train_data = vectorizer.fit_transform(train_data)

vec_train_data = vec_train_data.toarray()

train_data.shape, test_data.shape

vec_test_data = vectorizer.transform(test_data).toarray()

vec_train_data.shape , vec_test_data.shape

train_label.value_counts() # balanced partition

test_label.value_counts() # balanced partition

training_data = pd.DataFrame(vec_train_data , columns=vectorizer.get_feature_names())
testing_data = pd.DataFrame(vec_test_data , columns= vectorizer.get_feature_names())

from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score,classification_report

clf = MultinomialNB()
clf.fit(training_data, train_label)
y_pred = clf.predict(testing_data)

pd.Series(y_pred).value_counts()

test_label.value_counts()

print(classification_report(test_label , y_pred))

accuracy_score(test_label , y_pred)
accuracy_score

news = cleaning_data(str("Imposters posing as army personnel on the social media have been called out by the Indian Army as false news and disinformation."))
single_prediction = clf.predict(vectorizer.transform([news]).toarray())
single_prediction

news = cleaning_data(str("Is 5G Network Radiation Reason Behind Second Wave Of Coronavirus."))
single_prediction = clf.predict(vectorizer.transform([news]).toarray())
single_prediction

news = cleaning_data(str("China’s Out-of-Control Rocket Set to Re-Enter Earth’s Atmosphere."))
single_prediction = clf.predict(vectorizer.transform([news]).toarray())
single_prediction

news = cleaning_data(str("Modi has declared as best PM by UNESCOModi has declared as best PM by UNESCO"))
single_prediction = clf.predict(vectorizer.transform([news]).toarray())
single_prediction

news = cleaning_data(str("Cancer causing blood has been mised into Pepsi."))
single_prediction = clf.predict(vectorizer.transform([news]).toarray())
single_prediction

import joblib
joblib.dump(clf , 'model.pkl')

model = joblib.load('model.pkl')



